const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

// Initialize express app
const app = express();
app.use(cors());

// Create HTTP server using Express app
const server = http.createServer(app);

// Create Socket.io server with CORS settings
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Serve static files if we have a production build
app.use(express.static('build'));

// Keep track of active users
const users = {};
const rooms = {};

// Socket.io connection event handler
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  // When a user joins, store their ID and broadcast to other users
  socket.on('join', (userData) => {
    console.log(`User ${userData.name} joined with ID: ${socket.id}`);
    
    // Store user information
    users[socket.id] = { 
      id: socket.id, 
      name: userData.name,
      inCall: false
    };
    
    // Notify the joining user of all existing users
    socket.emit('all-users', Object.values(users).filter(user => user.id !== socket.id));
    
    // Notify other users about the new user
    socket.broadcast.emit('user-joined', users[socket.id]);
  });

  // Handle call requests
  socket.on('call-user', ({ userToCall, signalData, from, name }) => {
    console.log(`Call request from ${name} to ${userToCall}`);
    
    // If user exists and not in another call
    if (users[userToCall] && !users[userToCall].inCall) {
      // Create a unique room for this call
      const roomId = `${from}-${userToCall}`;
      rooms[roomId] = { participants: [from, userToCall] };
      
      // Mark users as in call
      users[from].inCall = true;
      users[userToCall].inCall = true;
      
      // Forward the call request to the intended recipient
      io.to(userToCall).emit('call-incoming', {
        signal: signalData,
        from,
        name,
        roomId
      });
      
      // Notify other users to update their available users list
      updateUserStatuses();
    } else {
      // User is unavailable
      socket.emit('call-unavailable', { 
        userToCall, 
        reason: users[userToCall] ? 'User is in another call' : 'User is offline' 
      });
    }
  });

  // Handle call acceptance
  socket.on('answer-call', ({ to, signal, roomId }) => {
    console.log(`Call answered by ${socket.id} to ${to}`);
    
    // Forward the answer to the caller
    io.to(to).emit('call-accepted', {
      signal,
      answeredBy: socket.id,
      roomId
    });
  });

  // Handle call ending
  socket.on('end-call', ({ roomId }) => {
    if (rooms[roomId]) {
      // Free up both users
      rooms[roomId].participants.forEach(userId => {
        if (users[userId]) {
          users[userId].inCall = false;
        }
      });
      
      // Remove the room
      delete rooms[roomId];
      
      // Notify all participants that the call has ended
      rooms[roomId]?.participants.forEach(userId => {
        if (userId !== socket.id) {
          io.to(userId).emit('call-ended');
        }
      });
      
      // Update all clients with new user statuses
      updateUserStatuses();
    }
  });

  // Handle call decline
  socket.on('decline-call', ({ from }) => {
    io.to(from).emit('call-declined', { by: socket.id });
  });

  // Handle ICE candidates exchange
  socket.on('ice-candidate', ({ to, candidate }) => {
    io.to(to).emit('ice-candidate', {
      from: socket.id,
      candidate
    });
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
    
    // Find any active calls this user was in
    for (const roomId in rooms) {
      if (rooms[roomId].participants.includes(socket.id)) {
        // Notify other participants that the call ended
        rooms[roomId].participants.forEach(userId => {
          if (userId !== socket.id && users[userId]) {
            users[userId].inCall = false;
            io.to(userId).emit('call-ended', { reason: 'User disconnected' });
          }
        });
        
        // Remove the room
        delete rooms[roomId];
      }
    }
    
    // Remove user from users list
    const disconnectedUser = users[socket.id];
    delete users[socket.id];
    
    // Notify other users about the disconnection
    if (disconnectedUser) {
      socket.broadcast.emit('user-left', socket.id);
    }
    
    // Update all clients with new user statuses
    updateUserStatuses();
  });

  // Helper function to update all clients with current user statuses
  function updateUserStatuses() {
    io.emit('user-statuses', Object.values(users).map(user => ({
      id: user.id,
      name: user.name,
      inCall: user.inCall
    })));
  }
});

// Define the port for the server
const PORT = process.env.PORT || 5000;

// Start the server
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});